from django.contrib import admin
from .models import InfoPictureAdd
# Register your models here.





admin.site.register(InfoPictureAdd)